from google.cloud import firestore
db=firestore.Client('esercizio-354309')

collection_ref=db.collection('dipendenti')

collection_ref.document('A123').set({'nome':'Vito Rossi', 'laureato': True, 'stipendio_annuo':28000})
collection_ref.document('A124').set({'nome':'Elena Bianchi', 'laureato': False, 'stipendio_annuo':25000})
collection_ref.document('A125').set({'nome':'Simone Gialli', 'laureato': False, 'stipendio_annuo':22000})
collection_ref.document('A126').set({'nome':'Andrea Neri', 'laureato': True, 'stipendio_annuo':30000})

print ('\n======================= TUTTI =======================\n')
for d in collection_ref.order_by('laureato').stream():
    print(d.to_dict())

print ('\n======================= RICERCA =======================\n')
res=collection_ref.where('stipendio_annuo','<',28000)\
.order_by('stipendio_annuo', direction=firestore.Query.DESCENDING)\
.limit(1)\
.stream()

#for d in res:
#    print(d.to_dict())

risultato=list(res)[0]
dati=risultato.to_dict()
print(f"Stipendio più alto sotto 28.000 euro appartiene a {dati['nome']}: {dati['stipendio_annuo']} euro")