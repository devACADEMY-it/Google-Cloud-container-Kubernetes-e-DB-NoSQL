from google.cloud import firestore
db=firestore.Client('esercizio-354309')

docs=db.collection('libri').stream()

for d in docs:
    print(f"Cancello \"{d.to_dict()['titolo']}\" (id={d.id})")
    d.reference.delete()