from google.cloud import firestore
db=firestore.Client('esercizio-354309')

print('\n======================= TUTTI =======================\n')
docs=db.collection('libri').order_by('pagine').stream()
for d in docs:
    print(d.to_dict())

print('\n======================= START_AT 102 =======================\n')
docs=db.collection('libri').order_by('pagine').start_at({'pagine':102}).stream()
for d in docs:
    print(d.to_dict())

print('\n======================= START_AFTER 102 =======================\n')
docs=db.collection('libri').order_by('pagine').start_after({'pagine':102}).stream()
for d in docs:
    print(d.to_dict())

print('\n======================= START_AT 102 e END_AT 450=======================\n')
docs=db.collection('libri').order_by('pagine')\
.start_at({'pagine':102})\
.end_at({'pagine':450})\
.stream()
for d in docs:
    print(d.to_dict())

print('\n======================= START_AT 102 e END_BEFORE 450=======================\n')
docs=db.collection('libri').order_by('pagine')\
.start_at({'pagine':102})\
.end_before({'pagine':450})\
.stream()
for d in docs:
    print(d.to_dict())