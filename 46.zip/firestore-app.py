from google.cloud import firestore

db = firestore.Client('firestore-app-360614')

db.collection('studenti').add({'nome': 'Lucia', 'cognome': 'Bianchi', 'matricola':'A12345'})
db.collection('studenti').add({'nome': 'Nino', 'cognome': 'Rossi', 'matricola':'A34567'})
db.collection('studenti').add({'nome': 'Paolo', 'cognome': 'Verdi', 'matricola':'A98765'})

docs = db.collection('studenti').stream()

for d in docs:
    print(f'ID {d.id}: {d.to_dict()}')

db.close()