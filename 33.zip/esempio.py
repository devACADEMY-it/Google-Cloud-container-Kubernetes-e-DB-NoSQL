from google.cloud import firestore

# inserire riferimento al proprio progetto Google
db=firestore.Client(PROGETTO_GOOGLE)

# inserire riferimento ad un documento del proprio database Firestore
doc=db.collection('amici').document('Hm6nlRcJF0QkgK06TJXC').get()

dati=doc.to_dict()

print(f"Abbiamo recuperato i dati di {dati['nome']} {dati['cognome']}")