import os
from flask import Flask
from google.cloud import firestore
import os

DB_PROJECT = os.environ.get('DB_PROJECT')
COLLECTION = os.environ.get('COLLECTION')

app = Flask(__name__)
db=firestore.Client(DB_PROJECT)


@app.route("/")
def hi():
    resp="<ul>"
    for d in db.collection(COLLECTION).stream():
        doc=d.to_dict()
        resp+=f"<li>{doc['nome']} {doc['cognome']} ({doc['eta']} anni)"
    resp+="</ul>"
    return resp

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
