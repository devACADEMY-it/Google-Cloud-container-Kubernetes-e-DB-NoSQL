import os
from flask import Flask
from DbManager import DbManager
from flask import jsonify, request, make_response, render_template

DB_PROJECT = os.environ.get('DB_PROJECT')
COLLECTION = os.environ.get('COLLECTION')

app = Flask(__name__)
manager=DbManager(DB_PROJECT, COLLECTION)

@app.route("/save", methods=['POST'])
def save():
    status, ref=manager.save(request.form.get('message'), request.form.get('times'))
    secret=f'{request.url_root}{ref}'
    return make_response(f'<h1>Il tuo segreto<br><a href="{secret}">{secret}</a></h1>', status)

@app.route("/<id>", methods=["GET"])
def get(id):
    _, message=manager.get(id)
    if message is None:
        return "<h1>Segreto non trovato o consumato</h1>", 404
    return render_template("get.html", message=message)

@app.route("/", methods=["GET"])
def home():
    return render_template("save.html")
    
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
