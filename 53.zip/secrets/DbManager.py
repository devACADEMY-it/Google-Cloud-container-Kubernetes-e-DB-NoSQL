from google.cloud import firestore
class DbManager:
  def __init__(self, project, collection):
    self.collection = collection
    self.project = project
    self.db=firestore.Client(project)
    self.collection_ref=self.db.collection(collection)

  def save(self, message, times):
    try:
        times=int(times)
        if times>=1:
            data={'message':message, 'times':times}
            ref=self.collection_ref.add(data)
            return 201,ref[1].id
        else:
            return 400, None
    except:
        return 400, None

  def get(self,id):
    doc=self.collection_ref.document(id).get()
    if doc.exists:
        res=doc.to_dict()
        if res['times']==1:
            doc.reference.delete()
        else:
            doc.reference.update({'times':res['times']-1})
        return 200,res['message']
    return 404, None